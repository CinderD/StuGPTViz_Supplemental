sample_labeled_data.json includes 12 samples of expert-labeled data (used for IG metric evaluation) and serves as a sample of our collected data.

Each data object represents a student's conversation data with ChatGPT for one learning task.

"student_name" and "student_full_name" are anonymized student IDs.
"question_score" is the student's final score for the learning task (question).
"prompts" is a list includes each turn of the student-ChatGPT interaction.

In each "prompts" list:

"prompt_number" is the index of the prompt.
"text_content" is the student's prompt content.
"codes" is a list includes the labels for the student's prompts according to the coding scheme introduced in Section 4.2 and Figure 3.
"gpt_response" is ChatGPT's response to the current "text_content".
"answer_relevancy" is the relevancy score of "gpt_response" according to the Ragas package introduced in Section 4.3.
"normed_answer_relevancy" is the normalized value of the "answer_relevancy".
"normed_gpt_response_length" is the normalized value of the text length of "gpt_response".

For our IG evaluation: 

"gpt_response_info_gain" is the IG metric result for this "gpt_response", based on the IG metric introduced in Section 4.3.
"expert_labeled_IG" is the average of two experts' score labels, serving as the ground truth for our IG metric evaluation, as described in Section 6.2.